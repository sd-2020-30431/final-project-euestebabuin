package server;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import com.esotericsoftware.kryonet.Server;

import comm.ClassRegister;
import comm.Player;
import comm.ComSC;

public class ServerConnection {

	Server server;
	ServerMain servma;
	ServerRunGame srg;
	
	public Server createServer(int tcp, int udp, ServerMain sm) {
		servma = sm;
		serverBind(tcp, udp);
		svAddListener();
		return server;
	}
	
	public void feedSGR(ServerRunGame _srg) {
		srg = _srg;
	}
	
	private void serverBind(int tcp, int udp) {
		server = new Server();
		ClassRegister.register(server);
	    server.start();
	    try {
			server.bind(tcp, udp);
		} catch (IOException e) {
			e.printStackTrace();
			
		}
	}
	
	private void svAddListener() {
		server.addListener(new Listener() {
		       public void received (Connection connection, Object object) {
		    	   
		    	   //String clientIP = connection.getRemoteAddressTCP().toString();
		          if (object instanceof Player) {
		        	  Player mesg = (Player)object;
		             servma.addPlayer(mesg.username, connection);
		          }
		          
		          if (object instanceof ComSC) {
		        	  ComSC mesg = (ComSC)object;
		        	  srg.processComSC(mesg);
		          }
		          
		          
		       }
		       public void connected(Connection connection) {
		    	   InetSocketAddress inet = connection.getRemoteAddressTCP();
		    	   servma.addLog("A client has connected to the server : " +inet);
		       }
		       public void disconnected(Connection connection) {
		    	   servma.addLog("A client has disconnected from the server");
		       }
		    });
	}
	
}
