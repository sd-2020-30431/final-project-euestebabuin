package server;

import java.awt.Point;

import comm.ComSC;
import gui.Aux_GUI;
import space.AbstractSpaceObj;
import space.Galaxy;
import space.Planet;
import space.Star;
import units.Fleet;
import units.Worker;

public class ModelModifier {
	
	
	
	private void updateFleet(Galaxy galaxy, Point fleet_pos, int delta) {
		for(AbstractSpaceObj aso : galaxy.astrals) {
			Fleet f = aso.local_fleet;
			if(f.getPosition().equals(fleet_pos)) {
				for(int i = 0; i < Math.abs(delta); i++)
					if(delta > 0)
						f.addToFleet(new Worker());
					else
						if(f.getFleetSize() > 0)
							f.removeFromFleet();
				aso.local_fleet = f;
			}
		}
	}
	
	private void invadeASOFree(Galaxy galaxy, Point object, int player_id) {
		for(AbstractSpaceObj aso : galaxy.astrals) 
			if(aso.getPos().equals(object)) {
				aso.setOwner(player_id);
				aso.local_fleet = createFleet(aso, player_id);
			}
	}
	
	private Fleet createFleet(AbstractSpaceObj aso, int pl_id) {
		int on_smth = 1;
		if (aso instanceof Star)
			if(aso.getPos().x == Aux_GUI.bh_x && aso.getPos().y == Aux_GUI.bh_y)
				on_smth = 3;
			else
				on_smth = 2;
		return new Fleet(aso.getPos(), on_smth, pl_id);
	}
	
	public Galaxy modify(Galaxy g, ComSC com) {
		switch(com.action) {
		case 'c': //create worker / fleet departs from planet
			Point pos = com.aso_s.getPos();
			updateFleet(g, pos, com.var);
			break;	
		case 'i': //invade a free planet // reinforce
			if(com.aso_d.getOwnerID() == com.pl.player_id ||
				com.aso_d.getOwnerID() == -1) {
				if(com.aso_d.getOwnerID() == com.pl.player_id) {
					updateFleet(g, com.aso_d.getPos(), com.var);
					System.out.println(com.pl.player_id + " " + com.aso_d.getOwnerID());
				}
				
				if(com.aso_d.getOwnerID() == -1) {	
					invadeASOFree(g, com.aso_d.getPos(), com.pl.player_id);		
					updateFleet(g, com.aso_d.getPos(), com.var);
				}
			}
			else
				 //invade occupied planet
				//defenders are more. they win
				if(com.aso_d.local_fleet.getFleetSize() > com.var)				
					updateFleet(g, com.aso_d.getPos(), -com.var);
				else {
					//equal attackers and defendants, one heroic defender remains
					if(com.aso_d.local_fleet.getFleetSize() == com.var)				
						updateFleet(g, com.aso_d.getPos(), -(com.var - 1));
					else
						if(com.aso_d.local_fleet.getFleetSize() < com.var) {
							invadeASOFree(g, com.aso_d.getPos(), com.pl.player_id);					
							updateFleet(g, com.aso_d.getPos(), com.var - com.aso_d.local_fleet.getFleetSize());
						}
				
				}
			break;
		
		case 'g':
			for(AbstractSpaceObj aso : g.astrals)
				if(aso.getPos().equals(com.aso_s.getPos()))
					((Star)aso).buildSG();
		}
		return g;
	}
	
}
