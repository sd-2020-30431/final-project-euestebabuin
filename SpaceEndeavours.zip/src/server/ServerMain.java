package server;

import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Server;

import comm.Player;
import gui.Aux_GUI;
import gui.GameInterfaceCreator;
import serverUI.Lobby;
import serverUI.ServerUI;
import space.Galaxy;
import space.Star;
import units.Worker;

public class ServerMain {
	private Server server; //the connection
	private ServerUI sui; //the minimalist log
	private Galaxy galaxy;
	private ArrayList<Player> players;
	private ArrayList<Connection> conns;
	private Lobby lobby;
	ServerConnection sc;
	
	public ServerMain(int tcp, int udp) {
		players = new ArrayList<Player>();
		conns = new ArrayList<Connection>();
		sc = new ServerConnection();
		server = sc.createServer(tcp, udp, this);
		sui = new ServerUI(server);
		lobby = new Lobby(this);
		lobby.showLobby();
	}
	
	public void sendAllCons(Object o) {
		for(Connection c : conns) {
			c.sendTCP(o);
		}
	}
	
	public void addPlayer(String username, Connection c) {
		lobby.addPlayer(username, players.size());
		Player pl = new Player(username, players.size());		
		players.add(pl);
		sendAllCons(pl);		
		conns.add(c);		
		for(Player p : players) {
			c.sendTCP(p);
		}
	}
	
	public void startGame() {
		GalaxyCreator gc = new GalaxyCreator();
		addLog("Creating Galaxy");
		galaxy = gc.createGalaxy(players);
		addLog("Galaxy Created");
		sendAllCons(galaxy);
		addLog("Galaxy sent");
		
		ServerRunGame srg = new ServerRunGame(galaxy, conns, players);
		sc.feedSGR(srg);
		
		sendAllCons("start");
		addLog("Starting Game");
		srg.runGame();
	}
	
	
	public void addLog(String s) {
		sui.addLog(s);
	}
	
	
	public static void main(String[] args) {
		new ServerMain(54555, 54777); 
		
	}

}
