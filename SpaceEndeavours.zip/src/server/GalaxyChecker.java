package server;

import java.awt.Point;
import java.util.ArrayList;

import comm.Player;
import gui.Aux_GUI;
import comm.ComSC;
import comm.Ongoing;
import space.AbstractSpaceObj;
import space.Galaxy;
import space.Planet;
import space.Star;
import units.Aux_Units;
import units.Fleet;

public class GalaxyChecker {


	Galaxy galaxy;
	ArrayList<Player> players;
	ServerRunGame srg;
	ModelModifier mm;
	
	
	public GalaxyChecker(Galaxy galaxy, ArrayList<Player> players,  ServerRunGame _srg) {
		super();
		this.galaxy = galaxy;
		this.players = players;
		srg = _srg;
		mm = new ModelModifier();
	}

	public int checkWin() {
		int one_player=-1;
		boolean win = true;
		for(AbstractSpaceObj aso : galaxy.astrals) {
			if(aso.getOwnerID() != -1) {
				if(one_player == -1)
					one_player = aso.getOwnerID();
				else {
					if(one_player != aso.getOwnerID())
						win = false;
				}
			}
			
		}
		if(win)
			return one_player;
		else
			return -1;
	}
	
	public int getEnergy(int player_id) {
		int produced = 0;
		for(AbstractSpaceObj aso : galaxy.astrals) {
			if (aso instanceof Planet &&  aso.getOwnerID() == player_id)
				produced += aso.local_fleet.getFleetSize() * Aux_Units.worker_E_produciton;
			if(aso instanceof Star && aso.getOwnerID() == player_id)
				produced += aso.local_fleet.getFleetSize() * Aux_Units.worker_E_produciton * 1.5;
			
		}
		return produced;
	}
	
	public int distance(Point a, Point b) {
    	return (int)Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));
    }
	
	private Ongoing createInvadeOngoing(ComSC req,float speed) {

		float fly_time = distance(req.aso_d.getPos(), req.aso_s.getPos()) / speed;
		
		Ongoing ong = new Ongoing(fly_time, fly_time,
				req.aso_s.getPos(), req.aso_d.getPos());
		Fleet f = new Fleet(req.var, req.pl.player_id);
		ong.com = new ComSC('i', null, req.aso_d, req.var, req.pl);
		ong.fleet = f;
		if(speed == Aux_GUI.teleport_speed)
			ong.com.is_teleport = true;
		
		return ong;
	}
	
	public Ongoing processRequest(ComSC req) {
		switch(req.action) {
		case 'c': //create
			int player_id = req.pl.player_id;
			Planet pl = (Planet)req.aso_s;
			if(players.get(player_id).energy > Aux_Units.worker_E_cost && 
					pl.local_fleet.getFleetSize() < Aux_Units.planet_max_occupants){
				
				players.get(player_id).energy -= Aux_Units.worker_E_cost;
				srg.sendEnergyUpdateOne(player_id);
				
				Ongoing ong = new Ongoing(Aux_Units.worker_create_time, Aux_Units.worker_create_time,
						pl.getPos(), null);
				ong.com = req;
				return ong;
			}
			break;
		case 'i' : //invasion
			if (req.aso_s.local_fleet.getFleetSize() -1 >= req.var && 
			req.aso_s.local_fleet.getFleetSize() > 0 && req.var > 0) {
				
				Ongoing ong = createInvadeOngoing(req, Aux_GUI.normal_ship_speed);
				ComSC com = new ComSC('c', req.aso_s, req.pl, -req.var);
				srg.sendAll(com);
				galaxy = mm.modify(galaxy, com);
				return ong;//req;
			}
			break;
		case 'g'://star gate
			if(players.get(req.pl.player_id).energy > Aux_Units.star_gate_cost && 
					!((Star)req.aso_s).hasSG()){
				players.get(req.pl.player_id).energy -= Aux_Units.star_gate_cost;
				srg.sendEnergyUpdateOne(req.pl.player_id);
				mm.modify(galaxy, req);
				srg.sendAll(req);
			}
			break;
		case 't'://teleport through hyperspace
			if (req.aso_s.local_fleet.getFleetSize() -1 >= req.var &&
			req.aso_s.local_fleet.getFleetSize() > 0 && req.var > 0) {
				
				Ongoing ong = createInvadeOngoing(req, Aux_GUI.teleport_speed);
				ComSC com = new ComSC('c', req.aso_s, req.pl, -req.var);
				srg.sendAll(com);
				galaxy = mm.modify(galaxy, com);
				return ong;//req;
			}
		}
		return null;
	}
	
	public AbstractSpaceObj refreshASO(AbstractSpaceObj asoTarget) {
		if(asoTarget != null) {
			for(AbstractSpaceObj aso : galaxy.astrals)
				if(aso.getPos().equals(asoTarget.getPos()))
					return aso;
		}
		return null;
	}
	//in case an attacker planet got reinforcements, it is refreshed from the galaxy
	public void directModify(ComSC req) {
		mm.modify(galaxy, req);
	}
}
