package server;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

import javax.swing.Timer;

import com.esotericsoftware.kryonet.Connection;

import comm.ComSC;
import comm.EnergyUpdate;
import comm.Ongoing;
import comm.Player;
import gui.Aux_GUI;
import space.Galaxy;

public class ServerRunGame implements ActionListener{

	ArrayList<Connection> conns;
	Timer t;
	int second_counter;
	GalaxyChecker gc;
	ArrayBlockingQueue<Ongoing> ev_queue;
	ArrayList<Player> players;
	boolean win_once;

	private final int DELAY = (int)(1000 / Aux_GUI.server_ops);
	

	public ServerRunGame(Galaxy galaxy, ArrayList<Connection> conns, ArrayList<Player> players) {
		super();
		this.conns = conns;
		this.players = players;
		this.win_once = true;

		ev_queue = new ArrayBlockingQueue<Ongoing>(140);
		second_counter = 0;
		gc = new GalaxyChecker(galaxy, players, this);
		t = new Timer(1000 / Aux_GUI.server_ops, this);
	}
	
	public void runGame() {
		t.start();
	}

	public void sendAll(Object com) {
		for(Connection c: conns)
			c.sendTCP(com);
	}
	
	public void sendEnergyUpdateOne(int id) {
		int produced = gc.getEnergy(id);
		gc.players.get(id).energy += produced;
		conns.get(id).sendTCP(new EnergyUpdate(gc.players.get(id).energy));
	}
	
	private void sendEnergyUpdate() {
		for(int i = 0; i < gc.players.size(); i++) {
			sendEnergyUpdateOne(i);
		}
	}
	
	public void processComSC(ComSC req) {
		Ongoing ong = (Ongoing)gc.processRequest(req);
		if(ong != null) {
			sendAll(ong);
			ev_queue.add(ong);
		}
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		second_counter++;
		int winner = gc.checkWin();
		if(winner != -1 && win_once) {
			win_once = false;
			sendAll(new ComSC(players.get(winner).username));
		}
		if(second_counter > Aux_GUI.server_ops) {
			sendEnergyUpdate();
			second_counter = 0;
		}
		for(Ongoing ong : ev_queue) {
			ong.time_left -= DELAY/1000.0f;
			if(ong.time_left <= 0) {

				ong.com.aso_d = gc.refreshASO(ong.com.aso_d);
				sendAll(ong.com);
				gc.directModify(ong.com);
				ev_queue.remove(ong);
			}
		}
	}
	
}
