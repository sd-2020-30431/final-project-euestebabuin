package server;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import comm.Player;
import gui.Aux_GUI;
import space.Galaxy;
import space.Star;
import space.Planet;
import units.Aux_Units;
import units.Fleet;
import units.Worker;

public class GalaxyCreator {

	ArrayList<Planet> all_planets;
	
	//creating coordinates for the galaxy in a DI manner
	public Galaxy createGalaxy(ArrayList<Player> players) {
		all_planets = new ArrayList<Planet>();
		ArrayList<Star> solars = createSolarSystems();
		populateSolarSystems(players.size(), solars);
		return new Galaxy(all_planets, solars, players);
	}
	//after we created the galaxy we "populate" it with players in the lobby
	private ArrayList<Fleet> populateSolarSystems(int nr_players, ArrayList<Star> solars) {
		ArrayList<Fleet> fleets = new ArrayList<Fleet>();
		for(int i = 0; i < nr_players; i++) {
			Point pos = all_planets.get(i * Aux_GUI.planets_per_ss).getPos();
			Fleet f = Aux_Units.create_initial_fleet(pos, i);
			fleets.add(f);
			all_planets.get(i * Aux_GUI.planets_per_ss).inhabitate(f, i);
		}
		return fleets;
	}
	
	private ArrayList<Star> createSolarSystems(){
		ArrayList<Star> solars = new ArrayList<Star>();
		int i = 0;
		Random r = new Random();
		while(i < Aux_GUI.solar_system_nr) {
			int ssx = Math.abs(r.nextInt()) % Aux_GUI.map_width;
            int ssy = Math.abs(r.nextInt()) % Aux_GUI.map_height;

            if(verify_ss(ssx, ssy, solars)){
            	i++;
            	
            	createPlanets(ssx, ssy, Aux_GUI.star_radius,  Aux_GUI.planets_per_ss);
            	Star ss = new Star(new Point(ssx,ssy), Aux_GUI.star_radius);
            	solars.add(ss);

            }
		}
		
		return solars;
	}
	
	private int distance(int ax, int ay, int bx, int by) {
    	return (int)Math.sqrt(Math.pow(ax - bx, 2) + Math.pow(ay - by, 2));
    }
	
	private boolean verify_ss(int ssx, int ssy, ArrayList<Star> solars) {
		boolean overlap = false;
		int ss_R =  Aux_GUI.ss_radius;
		for(Star s : solars) {//distance between solar systems
			int distance = distance(s.getPos().x, s.getPos().y, ssx, ssy);
			if(distance < ss_R + 1000)
				overlap = true;
		}
		if(ssx - ss_R > 0 && (ssx + ss_R * 2.5) < Aux_GUI.map_width &&
				ssy - ss_R > 0 && (ssy + ss_R * 2) < Aux_GUI.map_height &&
			distance(ssx, ssy, Aux_GUI.bh_x, Aux_GUI.bh_y) > Aux_GUI.bh_zone_radius + ss_R &&
			!overlap)
			return true;
		else 
			return false;
	}
	
	private boolean verify_p(int px, int py, int ss_R, ArrayList<Planet> planets, int ssx, int ssy) {
		boolean overlap = false;
		for(Planet p : planets) {//distance between planets
			int distance = distance(p.getPos().x, p.getPos().y, px, py);
			if(distance < 3 * Aux_GUI.planet_radius)//setting a minimum distance between planets
				overlap = true;
		}
		px -= ssx;
		py -= ssy;
		if(distance(px, py, 0, 0) < ss_R &&
				distance(px, py, 0, 0) > Aux_GUI.star_radius + 100 &&
				!overlap)
			return true;
		else 
			return false;
	}
	
	private ArrayList<Planet> createPlanets(int ssx, int ssy, int star_radius,  int nr_p){
		ArrayList<Planet> planets = new ArrayList<Planet>();
		int i = 0;
		int ss_radius =  Aux_GUI.ss_radius;
		Random r = new Random();
		while(i < nr_p) {

			//aboslute coordinates relative to star
			int px = r.nextInt() % (ss_radius);
            int py = r.nextInt() % (ss_radius);
            int p_text = Math.abs(r.nextInt()) % 6;
        	px += ssx;
        	py += ssy;
        	
            if(verify_p(px, py, ss_radius, planets, ssx, ssy)){
            	i++;
            	Planet p = new Planet(new Point(px, py), Aux_GUI.planet_radius, p_text);
            	planets.add(p);
            	all_planets.add(p);
            }
		}
		return planets;
	}
	
}
