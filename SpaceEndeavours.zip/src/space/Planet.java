package space;

import java.awt.Point;

import units.Fleet;
import units.Aux_Units;

public class Planet extends AbstractSpaceObj {
	public int planet_texture;
	public Planet() {
		super(new Point(0,0),0, -1, new Fleet());
	}

	public Planet(Point _pos, int _R, int texture) {
		super(_pos, _R, -1, new Fleet());
		planet_texture = texture;
	}
	
	public void inhabitate(Fleet f, int new_owner) {
		local_fleet = f;
		owned_by = new_owner;
	}
	
}
