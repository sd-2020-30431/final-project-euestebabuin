package space;

import java.awt.Point;
import java.util.ArrayList;

import comm.Player;
import gui.Aux_GUI;
import units.Fleet;

public class Galaxy {
	public ArrayList<AbstractSpaceObj> astrals;
	public ArrayList<Player> players;
	public Star Galactic_Core;
	public Galaxy(ArrayList<Planet> _planets, ArrayList<Star> _stars,
			ArrayList<Player> _players) {
		Galactic_Core = new Star(new Point(Aux_GUI.map_width/2, Aux_GUI.map_height/2), Aux_GUI.bh_radius);
		astrals = new ArrayList<AbstractSpaceObj>(_planets);
		astrals.addAll(_stars);
		players = _players;
	}
	
	public Galaxy() {
	}
}
