package space;

import java.awt.Point;

import units.Fleet;

public abstract class AbstractSpaceObj {
	private final  Point position;
	private final int R;
	protected int owned_by; //user id
	public Fleet local_fleet;
	public AbstractSpaceObj(Point _pos, int _R, int _owned_by, Fleet _local_fleet) {
		position = _pos;
		R = _R;
		owned_by = _owned_by;
		local_fleet = _local_fleet;
	}
	
	public Point getPos() {
		return position;
	}
	
	public int getR() {
		return R;
	}
	
	public int getOwnerID() {
		return owned_by;
	}
	
	public void setOwner(int player_id) {
		owned_by = player_id;
	}
}
