package space;

import java.awt.Point;
import java.util.ArrayList;

import units.Fleet;

public class Star extends AbstractSpaceObj {

	private boolean has_star_gate;
	
	//pos is position of the star, R is radius of Star, _owned_by is when 
	//someone controls the whole solar system
	public Star(Point _pos, int _R) {
		super(_pos, _R, -1, new Fleet());
		has_star_gate = false;
	}
	

	public boolean hasSG() {
		return has_star_gate;
	}
	
	public void buildSG() {
		has_star_gate = true;
	}
	
	public Star() {
		super(new Point(0,0), 0, -1, new Fleet());
	}
}
