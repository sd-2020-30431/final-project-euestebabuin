package client;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

import javax.swing.Timer;

import com.esotericsoftware.kryonet.Client;

import comm.Player;
import comm.ComSC;
import gui.Aux_GUI;
import gui.GameInterfaceCreator;
import server.ModelModifier;
import space.AbstractSpaceObj;
import space.Galaxy;
import space.Planet;
import space.Star;
import comm.Ongoing;
public class ClientRunGame implements ActionListener {
	Client client;
	Galaxy galaxy;
	Player player;
	GameInterfaceCreator gic;
	ModelModifier mm;
	ArrayBlockingQueue<Ongoing> ev_queue;
	
	private final int DELAY = (int)(1000 / Aux_GUI.fps);
    private Timer timer;
    String win_player = null;
	
	public ClientRunGame(Client client, Galaxy galaxy, Player _player) {
		super();
		this.client = client;
		this.galaxy = galaxy;
		player = _player;
		ev_queue = new ArrayBlockingQueue<Ongoing>(140);
		
		mm = new ModelModifier();
        timer = new Timer(DELAY, this);
        ClientRunGame crg = this;
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
        		gic = new GameInterfaceCreator(player, timer, galaxy, crg);
            }
        });
	}
	
	public void runGame() {
        timer.start();
	}
	
	public void updateEnergy(int energy) {
		player.energy = energy;
	}
	
	
	public void sendCreateCom(Planet p) {
		ComSC req = new ComSC('c', p, player, 1);//'c'reate on planet p a new worker
		client.sendTCP(req);
	}
	
	public void sendInvadeCom(char type, AbstractSpaceObj s, AbstractSpaceObj t, int nru) {
		ComSC req2 = new ComSC(type, s, t, nru, player);//'i'nvade planet/teleport
		client.sendTCP(req2);
	}
	
	public void sendStarGateReq(Star s) {
		ComSC req = new ComSC('g',s, player, 1); //create stargate on star s
		client.sendTCP(req);
	}
	//function which executes a received Command from the server
	public void executeCom(ComSC resp) {
		//winning
		if(resp.action != 'w')
			galaxy = mm.modify(galaxy, resp);
		else
			win_player = resp.win_user;
		
	}
	
	public void receiveOng(Ongoing o) {
		ev_queue.add(o);
	}
	
	
	
	//each fps the interface is refreshed
	@Override
	public void actionPerformed(ActionEvent arg0) {
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
        		gic.refreshInterface(galaxy, player, ev_queue, win_player);
        		for(Ongoing ong : ev_queue) {
        			ong.time_left -= DELAY/1000.0f;
        			if(ong.time_left <= 0)
        				ev_queue.remove(ong);
        		}
            }
        });
		
	}
	
}
