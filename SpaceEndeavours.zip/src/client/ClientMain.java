package client;

import java.awt.EventQueue;

import com.esotericsoftware.kryonet.Client;

import comm.Player;
import gui.PickUsername;
import serverUI.Lobby;
import space.Galaxy;

public class ClientMain {
	
	Client client; // the connection to the server
	PickUsername log; // firstUI
	String nickname;
	Lobby lobby;
	Player player;
	ClientConnection cc;
	ClientRunGame crg;
	
	public ClientMain(String hIP) {
		cc = new ClientConnection(this);
		client = cc.generateConnection(hIP);
		log = new PickUsername(this);
		lobby = new Lobby();
	}
	
	public void receiveNickname(String nick) {
		nickname = nick;
		Player pl = new Player();
		pl.username = nick;
		
		client.sendTCP(pl);
		lobby.showLobby();
	}
	
	
	public void addLobby(Player pl) {
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
            	if(nickname.compareTo(pl.username)==0)
        			player = pl;
        		lobby.addPlayer(pl.username, pl.player_id);	
            }
		});
		
	}
	
	
	public void startGame(Galaxy galaxy) {
		lobby.closeLobby();
		crg = new ClientRunGame(client, galaxy, player);
		cc.feedCGR(crg);		
	}
	
	public void runGame() {

		crg.runGame();
	}
	
	public static void main(String[] args) {
		new ClientMain("x.x.x.x"); //host's ip here
	}
}
