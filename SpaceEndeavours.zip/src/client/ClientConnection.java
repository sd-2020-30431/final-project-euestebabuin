package client;

import java.io.IOException;
import com.esotericsoftware.kryonet.Client;
import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;

import comm.ClassRegister;
import comm.ComSC;
import comm.EnergyUpdate;
import comm.Ongoing;
import comm.Player;
import space.Galaxy;


public class ClientConnection {

	Client client;
	ClientMain clma;
	ClientRunGame crg;
	
	public ClientConnection(ClientMain cm) {
		clma = cm;
	}
	
	public Client generateConnection(String hIP) {
		createClient(hIP);
		clAddListener(); 
		return client;
	}
	
	public void feedCGR(ClientRunGame _crg) {
		crg = _crg;
	}
	
	private void createClient(String hIP) {
		client = new Client();
		ClassRegister.register(client);
	    client.start();
	    try {
			client.connect(50000, hIP, 54555, 54777);
		} catch (IOException e) {
			e.printStackTrace();
		}    
	}

	private void clAddListener() {
		client.addListener(new Listener() {
		       public void received (Connection connection, Object object) {

		          if(object instanceof Player) {
		        	  Player resp = (Player)object;
		        	  clma.addLobby(resp);

		          }
		          
		          if(object instanceof Galaxy) {
		        	  Galaxy resp = (Galaxy)object;
		        	  clma.startGame(resp);
		          }
		          
		          if(object instanceof String) {
		        	  String resp = (String)object;
		        	  if(resp.compareTo("start") == 0)
		        		  clma.runGame();
		          }
		          
		          if(object instanceof EnergyUpdate) {
		        	  EnergyUpdate resp = (EnergyUpdate)object;
		        	  crg.updateEnergy(resp.new_energy);
		          }
		          
		          if(object instanceof ComSC) {
		        	  ComSC resp = (ComSC)object;
		        	  crg.executeCom(resp);
		          }
		          
		          if(object instanceof Ongoing) {
		        	  Ongoing resp = (Ongoing)object;
		        	  crg.receiveOng(resp);
		          }
		       }
		       
		       public void disconnected(Connection connection) {
		    	   System.exit(0);
		       }
		       
		    });
	}
}
