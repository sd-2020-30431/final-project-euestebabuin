package comm;

import space.AbstractSpaceObj;
import units.Fleet;

public class ComSC {

	public char action;
	public String win_user;
	public AbstractSpaceObj aso_s;
	public AbstractSpaceObj aso_d;
	public int var;
	public Fleet f;
	public Player pl;
	public boolean is_teleport = false;

	public ComSC() {
		super();
	}

	public ComSC(char action, AbstractSpaceObj aso, Player pl, int delta) {
		this.action = action;
		this.aso_s = aso;
		this.pl = pl;
		this.var = delta;
	}
	
	public ComSC(char action, AbstractSpaceObj source, AbstractSpaceObj dest,
			int nr_units, Player pl) {
		this.action = action;
		this.aso_s = source;
		this.aso_d = dest;
		var = nr_units;
		this.pl = pl;
	}
	
	public ComSC(String user) {
		win_user = user;
		action = 'w';
	}
	
	
}
