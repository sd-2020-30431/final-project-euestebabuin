package comm;
import java.awt.Point;

import units.Fleet;

public class Ongoing {

	public float time, time_left;//how much time it will take
	public Point source, dest;
	public ComSC com;
	public Fleet fleet;
	
	public Ongoing() {
		
	}

	public Ongoing(float time, float time_left, Point source, Point dest) {
		this.time = time;
		this.time_left = time_left;
		this.source = source;
		this.dest = dest;
		com = null;
	}


	
}
