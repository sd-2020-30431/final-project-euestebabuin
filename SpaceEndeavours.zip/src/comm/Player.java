package comm;

public class Player {
	public String username;
	public int player_id;
	public int energy;
	
	public Player() {}
	public Player(String u, int id) {
		username = u;
		player_id = id;
		energy = 0;
	}
}
