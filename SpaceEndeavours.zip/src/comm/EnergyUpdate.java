package comm;

public class EnergyUpdate {

	public int new_energy;

	public EnergyUpdate() {
		super();
	}

	public EnergyUpdate(int new_energy) {
		super();
		this.new_energy = new_energy;
	}
}
