package comm;

import java.awt.Point;
import java.util.ArrayList;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryonet.EndPoint;

import space.Galaxy;
import space.Planet;
import space.Star;
import units.Amiral;
import units.Fleet;
import units.Soldier;
import units.Worker;

public class ClassRegister {

	static public void register (EndPoint endPoint) {
		Kryo kryo = endPoint.getKryo();
		kryo.register(Player.class);
		
		kryo.register(Galaxy.class);
		kryo.register(Star.class);
		kryo.register(Planet.class);
		kryo.register(Fleet.class);
		kryo.register(Point.class);
		kryo.register(ArrayList.class);
		kryo.register(Worker.class);
		kryo.register(Soldier.class);
		kryo.register(Amiral.class);
		
		kryo.register(String.class);
		kryo.register(EnergyUpdate.class);
		kryo.register(ComSC.class);
		kryo.register(Ongoing.class);
	}
}
