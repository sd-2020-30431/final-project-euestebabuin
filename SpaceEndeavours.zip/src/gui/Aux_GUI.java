package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;

public class Aux_GUI {

	public final static int server_ops = 40;
	
	public final static int fps = 30;
	public final static Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	
	public final static int map_width = 15720;
	public final static int map_height = 8640;
	
	public final static int normal_ship_speed = 70;
	public final static int teleport_speed = 3000;
	
	
	public final static int solar_system_nr = 10;
	public final static int planets_per_ss = 8;
	
	public final static int bh_x = 7860;
	public final static int bh_y = 4320;
	public final static int bh_radius = 300;
	public final static int bh_zone_radius = 1000;
	public final static int ss_radius = 800;
	public final static int star_radius = 150;
	public final static int planet_radius = 50;
	
	public final static Color colors[] = {Color.BLUE, Color.RED, Color.GREEN, Color.YELLOW, Color.PINK,
			Color.ORANGE, Color.cyan, Color.WHITE};
	
	public Point transformCorner_Center(Point a) {
		
		return null;
	}
	
}
