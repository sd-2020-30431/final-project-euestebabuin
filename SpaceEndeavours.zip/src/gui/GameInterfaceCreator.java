package gui;


import java.awt.Color;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

import client.ClientRunGame;
import comm.Ongoing;
import comm.Player;
import space.AbstractSpaceObj;
import space.Galaxy;
import space.Planet;
import space.Star;
import units.Aux_Units;
import units.Fleet;

public class GameInterfaceCreator extends JFrame implements KeyListener, MouseListener {

	final Surface surface;
	Timer timer;
	ClientRunGame crg;
	Player player;
	AbstractSpaceObj selectedObj = new Planet(), last_clicked = new Planet();
	int milis_since_clicked = 0;
	JTextField nr_units;
	JFrame fr;
	private final int DELAY = (int)(1000 / Aux_GUI.fps);
	
    public GameInterfaceCreator(Player _player, Timer _timer, Galaxy g, ClientRunGame _crg) {
        selectedObj = new Planet();
        surface = new Surface(_player, g);
        timer = _timer;
        crg = _crg;
        initUI();
    }

    private void initUI() {
        add(surface);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                timer.stop();
            }
        });

        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addKeyListener(this);
		this.addMouseListener(this);
		this.isFocused();

        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setUndecorated(true);
        this.setVisible(true);
    }

    public void refreshInterface(Galaxy galaxy, Player player,
    		ArrayBlockingQueue<Ongoing> ev_queue, String win_pl) {
    	this.player = player;
    	surface.refresh(galaxy, player, selectedObj, ev_queue, win_pl);
    	milis_since_clicked += DELAY;
    }
    
	

	private JButton createButton(String s, ActionListener al) {
		JButton rez = new JButton(s);
		rez.setBackground(Color.black);
		rez.setForeground(Color.white);
		rez.addActionListener(al);
		return rez;
	}
	
	//create appropiate window for user interaction
	private void createWindow(Object o) {
		if(fr != null)
			fr.setVisible(false);
		fr = new JFrame();	
		JPanel jp = new JPanel();
		jp.setForeground(Color.BLACK);
		jp.setBackground(Color.BLACK);
		
		if(o instanceof AbstractSpaceObj) {
			AbstractSpaceObj aso = (AbstractSpaceObj)o;
			if(selectedObj instanceof Star && ((Star)selectedObj).hasSG()) {
				jp.add(createButton("Teleport", new ClickSpaceObj(aso, 't')));
			}
				if(aso.getOwnerID() == player.player_id) {
					if(aso instanceof Planet) 
						jp.add(createButton("Create Unit", new ClickSpaceObj((Planet)aso, 'c')));
						if(!(selectedObj.getPos().equals(aso.getPos()))) {
							jp.add(createButton("Select", new ClickSpaceObj(aso, 's')));
							jp.add(createButton("Reinforce", new ClickSpaceObj(aso, 'i')));
							nr_units = new JTextField("" + (selectedObj.local_fleet.getFleetSize() - 1));
							nr_units.addMouseListener(this);
							jp.add(nr_units);
						}
				}
				else 
				if(selectedObj != null && selectedObj.local_fleet.getFleetSize() > 1){
					jp.add(createButton("Invade", new ClickSpaceObj(aso, 'i')));
					nr_units = new JTextField("" + (selectedObj.local_fleet.getFleetSize() - 1));
					nr_units.addMouseListener(this);
					jp.add(nr_units);
				}
				
				if(aso instanceof Star && aso.getOwnerID() == player.player_id) {
					if(!((Star)aso).hasSG())
						jp.add(createButton("Create StarGate", new ClickSpaceObj((Star)aso, 'g')));
				}
				
		}
		fr.setContentPane(jp);
		fr.pack();
		fr.setLocation(Aux_GUI.screenSize.width/2, Aux_GUI.screenSize.height/2);
		fr.setVisible(true);
	}
	
	
	
	private class ClickSpaceObj implements ActionListener{
		AbstractSpaceObj aso;
		char action;
		
		public ClickSpaceObj(AbstractSpaceObj as, char c) {
			aso = as;
			action = c;
		}
		
		public void actionPerformed(ActionEvent arg0) {	
			if(action == 'c' && surface.notOngoing(aso.getPos()) && 
					aso.local_fleet.getFleetSize() < Aux_Units.planet_max_occupants) {//create
				fr.setVisible(false);
				crg.sendCreateCom((Planet)aso);
			}else
			if(action == 's')//select planet to send troops for invasion
			{
				fr.setVisible(false);
				selectedObj = aso;
			}else
			if(action == 'i') {//invade
				fr.setVisible(false);
				int nru = Integer.parseInt(nr_units.getText());
				crg.sendInvadeCom('i', selectedObj, aso, nru);
			}
			else
			if(action == 'g') {//createStarGate
				fr.setVisible(false);
				crg.sendStarGateReq((Star) aso);
			}
			if(action == 't') {//teleport
				fr.setVisible(false);
				int nru = Integer.parseInt(nr_units.getText());
				crg.sendInvadeCom('t', selectedObj, aso, nru);
			}
				
		}
		
    }
	
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		AbstractSpaceObj clicked = surface.checkClick(MouseInfo.getPointerInfo().getLocation());
		if(clicked != null) {
			if(clicked instanceof AbstractSpaceObj) {
				createWindow(clicked);
			}			
		}
		if(clicked.getPos().equals(last_clicked.getPos()) && milis_since_clicked < 600) 
			if(clicked instanceof Planet && surface.notOngoing(clicked.getPos()) && 
					clicked.local_fleet.getFleetSize() < Aux_Units.planet_max_occupants) {
				crg.sendCreateCom((Planet)clicked);
				fr.setVisible(false);
			}
		last_clicked = clicked;
		milis_since_clicked = 0;
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyChar() == 's')
			surface.set_pan_speed(75);
		if(e.getKeyChar() == 'h')
			surface.return_home();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if(e.getKeyChar() == 's')
			surface.set_pan_speed(25);
		
	}


	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}	
	
	//unnecessary
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		//select planet
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		//all units attack
	}
	
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}