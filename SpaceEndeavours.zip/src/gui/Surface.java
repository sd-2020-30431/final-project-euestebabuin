package gui;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

import javax.swing.JPanel;

import comm.Ongoing;
import comm.Player;
import space.AbstractSpaceObj;
import space.Galaxy;
import space.Planet;
import space.Star;
import units.Fleet;

public class Surface extends JPanel {

    private SurfaceAuxFunctions picker;
    private ImageLoader imgL;
    
    private Point screen_pos;
    private Point initial_screen_pos;
    private int Sheight;
    private int Swidth;
    private int screen_pan_speed;
    private String win_pl = null;
    
    private AbstractSpaceObj selectedObj = new Planet();;
    
    private Player player;
    private Galaxy galaxy;
    ArrayList<Star> vis_solars;
    ArrayBlockingQueue<Ongoing> ev_queue;

    public Surface(Player _player, Galaxy g) {

    	player = _player;
    	galaxy = g;
    	setVariables();
    }

    private void setVariables() {
    	imgL = new ImageLoader();
    	picker = new SurfaceAuxFunctions();
    	Swidth = Aux_GUI.screenSize.width;
		Sheight = Aux_GUI.screenSize.height;
		screen_pan_speed = 25;
		screen_pos = picker.initial_screen_coords(galaxy, player.player_id);
		initial_screen_pos = new Point(screen_pos.x, screen_pos.y);
		vis_solars = picker.getObjects(galaxy, screen_pos);
    }
    
    private void checkMovement() {
        Point mouse = MouseInfo.getPointerInfo().getLocation();
    	if(mouse.x + 50 > Swidth && (screen_pos.x + Swidth * 2) < (imgL.wallpaper.getWidth() * 2 - screen_pan_speed) )
        	screen_pos.x+=screen_pan_speed;
        if(mouse.y + 50 > Sheight && (screen_pos.y + Sheight * 2) < (imgL.wallpaper.getHeight() * 2 - screen_pan_speed))
        	screen_pos.y+=screen_pan_speed;
        if(mouse.x - 50 < 0 && screen_pos.x - screen_pan_speed > 0)
        	screen_pos.x-=screen_pan_speed;
        if(mouse.y - 50 < 0 && screen_pos.y - screen_pan_speed > 0)
        	screen_pos.y-=screen_pan_speed;
    }
    
    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        
        BufferedImage wallpaper2 = imgL.wallpaper.getSubimage(screen_pos.x/2, screen_pos.y/2, Swidth, Sheight);
        g2d.drawImage(wallpaper2,0,0,Swidth, Sheight, null);

        paintAstrals(g2d);
        paintFleets(g2d);
        paintEnergy(g2d);
        
        if(win_pl != null) {
        	g2d.setFont(new Font("Serif", Font.BOLD, 100));
            g2d.setPaint(Color.white);
            g2d.drawString(win_pl + " won the game!",
            		Aux_GUI.screenSize.width / 2 - 350, Aux_GUI.screenSize.height / 2 - 70);
        }
        
        g2d.dispose();
    }

    
    private void paintAstrals(Graphics2D g2d) {
    	
        for(Star ss : vis_solars) {
        	//draw coordinates
        	Point cornerC = picker.cornerCoords(ss.getPos(), ss.getR(), screen_pos);
        	
        	
        	if(selectedObj.getPos().equals(ss.getPos())){
        		g2d.setPaint(Color.white);
        		g2d.fillOval(cornerC.x - 5, cornerC.y - 5, Aux_GUI.star_radius * 2 + 10, Aux_GUI.star_radius * 2 + 10);
        	}

        	if(ss.hasSG())
        		g2d.drawImage(imgL.sunImgG, cornerC.x, cornerC.y, Aux_GUI.star_radius * 2, Aux_GUI.star_radius * 2, null);
        	else
        		g2d.drawImage(imgL.sunImg, cornerC.x, cornerC.y, Aux_GUI.star_radius * 2, Aux_GUI.star_radius * 2, null);
        	if(ss.getOwnerID() != -1) {
           	 	//conquered astral objects have the same color as the player
        		g2d.setComposite(AlphaComposite.getInstance(
                        AlphaComposite.SRC_OVER, 0.5f));
        		
            	g2d.setPaint(Aux_GUI.colors[ss.getOwnerID()]);
        		g2d.fillOval(cornerC.x, cornerC.y, Aux_GUI.star_radius * 2, Aux_GUI.star_radius * 2);
        		
        		g2d.setComposite(AlphaComposite.getInstance(
                        AlphaComposite.SRC_OVER, 1));
        	}
        }
        
    	for(AbstractSpaceObj aso : galaxy.astrals) {
    		if(aso instanceof Planet) {
    			Planet p = (Planet)aso;
	    		if(picker.distance(p.getPos(), screen_pos) < 3000) {
		        	Point cornerC = picker.cornerCoords(p.getPos(), p.getR(), screen_pos);
		        	
	    			
		        	if(selectedObj.getPos().equals(p.getPos())){
		        		g2d.setPaint(Color.white);
		        		g2d.fillOval(cornerC.x-5, cornerC.y-5, Aux_GUI.planet_radius * 2 + 10, Aux_GUI.planet_radius * 2 + 10);
		        	}

	        		g2d.drawImage(imgL.planetsImg.get(p.planet_texture), cornerC.x, cornerC.y, Aux_GUI.planet_radius * 2, Aux_GUI.planet_radius * 2, null);
		        	if(p.getOwnerID() != -1) {
		        		g2d.setComposite(AlphaComposite.getInstance(
		                        AlphaComposite.SRC_OVER, 0.5f));
		        	   	g2d.setPaint(Aux_GUI.colors[p.getOwnerID()]);
		        	   	
		        		g2d.fillOval(cornerC.x, cornerC.y, Aux_GUI.planet_radius * 2, Aux_GUI.planet_radius * 2);
		        		
		        		g2d.setComposite(AlphaComposite.getInstance(
		                        AlphaComposite.SRC_OVER, 1));     
		        	}
		        	
		        	if(ev_queue != null)
		    			for(Ongoing ong : ev_queue) {
		    				if(ong.source.equals(p.getPos()) && ong.dest == null){
		    					int progress = (int)(Aux_GUI.planet_radius * 2 * ((ong.time - ong.time_left)/ong.time));
		    					g2d.setPaint(Color.green);
		    					g2d.fillRect(cornerC.x, cornerC.y - 50, progress, 10);
		    				}
		    				if(ong.dest != null && ong.dest.equals(p.getPos()) && ong.com.is_teleport == true) {
		    					g2d.setPaint(Color.red);
		    					g2d.fillRect(ong.dest.x -screen_pos.x - 10, ong.dest.y-screen_pos.y - 30 - Aux_GUI.planet_radius, 20, Aux_GUI.planet_radius * 2 + 60);
		    					g2d.fillRect(ong.dest.x -screen_pos.x- 30 - Aux_GUI.planet_radius, ong.dest.y-screen_pos.y - 10, Aux_GUI.planet_radius * 2 + 60, 20);
		    					g2d.drawOval(cornerC.x-2, cornerC.y-2, Aux_GUI.planet_radius * 2 + 4, Aux_GUI.planet_radius * 2 + 4);
		    				}
		    			}
		        }
	    	}
    	}
    }
    
    
    private void paintFleetTriangle(Graphics2D g2d, Ongoing ong, int value) {
    	int value_aux = ong.fleet.getFleetSize();
    	int rows;
    	for(rows = 1; value_aux > 0; value_aux -= rows, rows++);
    	value_aux = ong.fleet.getFleetSize();
    	for(int i = 1,  k = 0; i < rows; i++) {
    		for(int j = 0; j < i && k < value_aux; j++, k++)
    		g2d.drawImage(imgL.unitsImg.get(ong.fleet.getOwnerID()), ong.source.x - screen_pos.x - 15 * (i-1) + 30 * j,			
    				(int)(ong.source.y -screen_pos.y + value - 30 * (i-1)) , 30, -30, null);
    	}
    	
    }
    
    private void paintFleets(Graphics2D g2d) {
    	for(AbstractSpaceObj aso : galaxy.astrals) {
    		Fleet f = aso.local_fleet;
    		if(f.getPosition().x != -1 && f.on_smth > 0) {
    			for(int i = 0; i < f.getFleetSize(); i++) {
    				AffineTransform old = g2d.getTransform();
    				g2d.rotate(Math.toRadians(360 / f.getFleetSize() * i), f.getPosition().x - screen_pos.x, f.getPosition().y - screen_pos.y);
    				int smth_radius = Aux_GUI.planet_radius;
    				if(f.on_smth == 2)
    					smth_radius = Aux_GUI.star_radius;
    				if(f.on_smth == 3)
    					smth_radius = Aux_GUI.bh_radius;
    				g2d.drawImage(imgL.unitsImg.get(f.getOwnerID()), f.getPosition().x- screen_pos.x - 15,
    						f.getPosition().y - screen_pos.y - smth_radius - 30 , 30, 30, null);
    				g2d.setTransform(old);
    			}
    		}
    	}
    	if(ev_queue != null)
    	for(Ongoing ong : ev_queue) { 
    		if(ong.dest != null) {
    			float progress = (ong.time - ong.time_left)/ong.time;
    			int dist = picker.distance(ong.dest, ong.source);
    			AffineTransform old = g2d.getTransform();
				g2d.rotate(Math.toRadians(picker.getAngle(ong.dest, ong.source) - 90),
						ong.source.x-screen_pos.x, ong.source.y-screen_pos.y);
				
				paintFleetTriangle(g2d, ong, (int)(dist * progress));
    			g2d.setTransform(old);
    		}
    	}
    }
    
    private void paintEnergy(Graphics g2d) {
    	g2d.setColor(Color.BLACK);
    	g2d.fillRect(0, 0, 100, 30);
    	g2d.setColor(Color.white);
    	g2d.drawString("Energy:" + player.energy, 0, 20);
    }
    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
    }

    public void refresh(Galaxy _galaxy, Player _player,AbstractSpaceObj _selectedObj, 
    		ArrayBlockingQueue<Ongoing> _ev_queue, String win_pl) {
    	galaxy = _galaxy;
    	player = _player;
    	selectedObj = _selectedObj;
    	ev_queue = _ev_queue;
    	checkMovement();
    	vis_solars = picker.getObjects(galaxy, screen_pos);
    	if(win_pl != null)
    		this.win_pl = win_pl;
        repaint();
    }

	public void set_pan_speed(int s) {
		screen_pan_speed = s;
	}
	
	public void return_home() {
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
        		screen_pos = new Point(initial_screen_pos.x, initial_screen_pos.y);
            }
        });
	}
	
	public AbstractSpaceObj checkClick(Point click) {
		click.x += screen_pos.x;
		click.y += screen_pos.y;
		for(AbstractSpaceObj aso : galaxy.astrals) {
			if (aso instanceof Planet && picker.distance(aso.getPos(), click) < Aux_GUI.planet_radius)
				return aso;
			if(aso instanceof Star && picker.distance(aso.getPos(), click) < Aux_GUI.star_radius)
				return aso;
			
		}
		if(picker.distance(new Point(Aux_GUI.bh_x, Aux_GUI.bh_y), click) < Aux_GUI.bh_radius)
			return galaxy.Galactic_Core;
		
		return null;
	}
	
	public boolean notOngoing(Point planet) {
	    	for(Ongoing ong : ev_queue) 
	    		if(ong.dest == null) {
	    			if(planet.equals(ong.source)) {
	    				return false;
	    			}	   
	    		}
		return true;
	}
}