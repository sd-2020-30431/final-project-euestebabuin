package gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import client.ClientMain;


public class PickUsername {
	
	JTextField user;
	JFrame fr;
	ClientMain cm;
	
	public PickUsername(ClientMain _cm){
		initGUI();
		cm = _cm;
	}

	
	private void initGUI() {

		user = new JTextField(15);
		
		fr = new JFrame("Welcome to Space Endeavours!");	
		fr.setContentPane(makeTextBox());
		fr.pack();
		fr.setSize(350, 170);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		/*URL iconURL = getClass().getResource("res\\img\\ss1.png");
		ImageIcon icon = new ImageIcon(iconURL);
		fr.setIconImage(icon.getImage());*/
		fr.setVisible(true);
	}

	
	JPanel makeTextBox() {
		JPanel jp = new JPanel();
		jp.setLayout(new BoxLayout(jp, BoxLayout.Y_AXIS));
			
		JPanel pan0 = new JPanel();
		pan0.setBackground(Color.BLACK);
		pan0.setForeground(Color.BLACK);
		JLabel welcome = new JLabel("Will you prove youself worthy to");
		welcome.setForeground(Color.WHITE);
		pan0.add(welcome);
		JLabel welcome2 = new JLabel("CONQUER THE GALAXY?");
		welcome2.setForeground(Color.WHITE);
		pan0.add(welcome2);
		welcome.setAlignmentX(JLabel.CENTER_ALIGNMENT);
		jp.add(pan0);
		
		JPanel pan1 = new JPanel();
		pan1.setBackground(Color.BLACK);
		pan1.setForeground(Color.BLACK);
		
		JLabel nickn = new JLabel("Nickname:");	
		nickn.setForeground(Color.WHITE);
		pan1.add(nickn);
		pan1.add(user);
		jp.add(pan1);
		
		JPanel pan3 = new JPanel();
		JButton login = new JButton("Start Game");
		login.setBackground(Color.black);
		login.setForeground(Color.white);
		login.addActionListener(new ClickStart());
		pan3.add(login);
		login.setAlignmentX(JButton.CENTER_ALIGNMENT);
		pan3.setBackground(Color.BLACK);
		pan3.setForeground(Color.BLACK);
		jp.add(pan3);
		
		return jp;
	}

	
	private class ClickStart implements ActionListener{
		
		public void actionPerformed(ActionEvent arg0) {	
			if (!user.getText().isEmpty()) {
				cm.receiveNickname(user.getText());
				fr.setVisible(false);
			}
			else
				JOptionPane.showMessageDialog(null, "You must first pick a nickname!",
						"Type something!", JOptionPane.WARNING_MESSAGE);
		}
		
    }
}
