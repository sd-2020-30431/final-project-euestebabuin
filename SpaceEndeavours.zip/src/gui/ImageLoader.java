package gui;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class ImageLoader {

    public BufferedImage wallpaper, sunImg, planetImg, sunImgG;
    public ArrayList<BufferedImage> planetsImg;
    public ArrayList<BufferedImage> unitsImg;
    
    public ImageLoader() {
    	planetsImg = new ArrayList<BufferedImage>();
    	unitsImg = new ArrayList<BufferedImage>();
    	loadImages();
    }
    
    private void loadImages() {
    	try {
			wallpaper = ImageIO.read(new File("res\\img\\wallpaper.jpg"));
			
			sunImg = ImageIO.read(new File("res\\img\\astral\\sun.png"));
			sunImgG = ImageIO.read(new File("res\\img\\astral\\sunG.png"));
			
			planetsImg.add(ImageIO.read(new File("res\\img\\astral\\planet.png")));
			planetsImg.add(ImageIO.read(new File("res\\img\\astral\\planet1.png")));
			planetsImg.add(ImageIO.read(new File("res\\img\\astral\\planet2.png")));
			planetsImg.add(ImageIO.read(new File("res\\img\\astral\\planet3.png")));
			planetsImg.add(ImageIO.read(new File("res\\img\\astral\\planet4.png")));
			planetsImg.add(ImageIO.read(new File("res\\img\\astral\\planet5.png")));
			
			unitsImg.add(ImageIO.read(new File("res\\img\\unit\\unit_blue.png")));
			unitsImg.add(ImageIO.read(new File("res\\img\\unit\\unit_red.png")));
			unitsImg.add(ImageIO.read(new File("res\\img\\unit\\unit_green.png")));
			unitsImg.add(ImageIO.read(new File("res\\img\\unit\\unit_yellow.png")));
			unitsImg.add(ImageIO.read(new File("res\\img\\unit\\unit_pink.png")));
			unitsImg.add(ImageIO.read(new File("res\\img\\unit\\unit_orange.png")));
			unitsImg.add(ImageIO.read(new File("res\\img\\unit\\unit_cyan.png")));
			unitsImg.add(ImageIO.read(new File("res\\img\\unit\\unit_white.png")));
			
		} catch (IOException e) {
			System.out.println("Images - bad locations");
		}
    }
}
