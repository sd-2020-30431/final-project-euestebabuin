package gui;

import java.awt.Point;
import java.util.ArrayList;

import space.AbstractSpaceObj;
import space.Galaxy;
import space.Planet;
import space.Star;

public class SurfaceAuxFunctions {

	
	public int distance(Point a, Point b) {
    	return (int)Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));
    }
	
	private Point screenMiddle(Point a) {
		return new Point(a.x + Aux_GUI.screenSize.width/2, a.y + Aux_GUI.screenSize.height/2);
	}
	
	public Point screenCoords(Point a, Point screen_pos) {
    	return new Point(a.x- screen_pos.x, a.y - screen_pos.y);
    }
	
    public Point cornerCoords(Point a, int R, Point screen_pos) {
    	return new Point(a.x - R - screen_pos.x, a.y - R - screen_pos.y);
    }
	
    public Point getPartialFleetPos(Point s, Point d, float progress) {
    	int x = (int)(s.x + (d.x - s.x) * progress);
    	int y = (int)(s.y + (d.y - s.y) * progress);
    	return new Point(x, y);
    }
    
    public float getAngle(Point target, Point source) {
        float angle = (float) Math.toDegrees(Math.atan2(target.y - source.y, target.x - source.x));

        if(angle < 0){
            angle += 360;
        }

        return angle;
    }
    
	
	//picks which objects will be rendered
	public ArrayList<Star> getObjects(Galaxy galaxy, Point s_coords){
		Point middle = screenMiddle(s_coords);
		ArrayList<Star> objects = new ArrayList<Star>();
		for(AbstractSpaceObj ss : galaxy.astrals)
			if(ss instanceof Star &&distance(ss.getPos(), middle) < Aux_GUI.ss_radius + Aux_GUI.screenSize.width)
				objects.add((Star)ss);
		return objects;
	}
	
	public Point initial_screen_coords(Galaxy galaxy, int player_id) {
		for(AbstractSpaceObj p : galaxy.astrals)
			if(p instanceof Planet && p.getOwnerID() == player_id)
			{
				//initial coords are viewing starting planet in the middle
				Point planet_pos = p.getPos();
				Point check = new Point(planet_pos.x - Aux_GUI.screenSize.width/2,
						planet_pos.y - Aux_GUI.screenSize.height/2);
				//check for planets on the edge of the map
				//5 is just orientative, to be sure
				if (check.x + Aux_GUI.screenSize.width*2 > Aux_GUI.map_width)
					check.x =  Aux_GUI.map_width - Aux_GUI.screenSize.width * 2 - 5;
				if (check.y + Aux_GUI.screenSize.height*2 > Aux_GUI.map_height)
					check.y =  Aux_GUI.map_height - Aux_GUI.screenSize.height * 2 - 5;
				if(check.x < 0)
					check.x = 0;
				if(check.y < 0)
					check.y = 0;
				return check;
			}
		return null;
	}
	
}
