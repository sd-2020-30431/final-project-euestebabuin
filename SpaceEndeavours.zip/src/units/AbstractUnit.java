package units;

public abstract class AbstractUnit {
	private int hp;
	public AbstractUnit(int _hp) {
		hp = _hp;
	}
	
	public void take_damage(int damage) {
		hp -= damage;
	}
}
