package units;

public class Worker extends AbstractUnit {
	
	public Worker() {
		super(10);
	}

}
