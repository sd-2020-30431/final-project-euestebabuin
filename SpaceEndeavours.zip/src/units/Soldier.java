package units;

public class Soldier extends AbstractUnit {

	public Soldier(int _hp) {
		super(_hp);
	}
	
}
