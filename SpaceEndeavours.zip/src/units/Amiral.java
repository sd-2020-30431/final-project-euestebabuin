package units;

public class Amiral extends AbstractUnit {
	
	public Amiral(int _hp) {
		super(_hp);
	}
}
