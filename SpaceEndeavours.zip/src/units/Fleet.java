package units;

import java.awt.Point;
import java.util.ArrayList;

public class Fleet {
	private Point position;
	private ArrayList<AbstractUnit> units;
	public int on_smth;//0 in space, 1 on planet, 2 on star, 3 on bhole
	private int player_id;
	public Fleet(ArrayList<AbstractUnit> initial_units,Point initial_pos,
			int _on_smth, int _id) {
		units = new ArrayList<AbstractUnit>(initial_units);
		position = initial_pos;
		on_smth = _on_smth;
		player_id = _id;
	}
	
	public Fleet(Point initial_pos,int _on_smth, int _id) {
		units = new ArrayList<AbstractUnit>();
		position = initial_pos;
		on_smth = _on_smth;
		player_id = _id;
	}
	
	public Fleet(int nr_units, int _player_id) {
		units = new ArrayList<AbstractUnit>();
		for(int i = 0; i < nr_units; i++) 
			addToFleet();
		position = new Point(0,0);
		on_smth = 0;
		player_id = _player_id;
		
	}
	
	public void addToFleet() {
		units.add(new Worker());
	}
	
	public void addToFleet(AbstractUnit au) {
		units.add(au);
	}
	
	public void removeFromFleet() {
		units.remove(0);
	}
	
	public Fleet() {
		units = new ArrayList<AbstractUnit>();
		position = new Point(-1, -1);
	}
	public void setPosition(Point newPos) {
		position = newPos;
	}

	public int getFleetSize() {
		return units.size();
	}

	public int getOwnerID() {
		return player_id;
	}
	
	public Point getPosition() {
		return position;
	}
	
}
