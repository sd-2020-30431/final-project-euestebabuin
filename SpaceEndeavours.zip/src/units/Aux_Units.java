package units;

import java.awt.Point;
import java.util.ArrayList;

public final class Aux_Units {
	public final static int worker_E_produciton = 2;
	public final static int worker_E_cost = 100;
	public final static int worker_create_time = 5;
	public final static int star_gate_cost = 1000;
	
	public final static int nr_initial_workers = 4;
	public final static int planet_max_occupants = 15;
	
	public static Fleet create_initial_fleet(Point pos, int player_id) {
		ArrayList<AbstractUnit> aux = new ArrayList<AbstractUnit>();
		for(int i = 0; i < nr_initial_workers; i++, aux.add(new Worker()));
		return new Fleet(aux, pos, 1, player_id);
	}
}
