package serverUI;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


import gui.Aux_GUI;
import server.ServerMain;

public class Lobby {
	JFrame frame;
	JPanel pan;
	JTextArea jta;
	ServerMain sm;
	
	public Lobby(ServerMain _sm) {
		sm = _sm;
		init();
	}
	
	public Lobby() {
		sm = null;
		init();
	}
	
	private void init() {
		frame = new JFrame("Lobby");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel mainpanel = new JPanel();
		mainpanel.setLayout(new BoxLayout(mainpanel, BoxLayout.Y_AXIS));
		mainpanel.setForeground(Color.BLACK);
		mainpanel.setBackground(Color.BLACK);
		
		pan = new JPanel();
		pan.setLayout(new BoxLayout(pan, BoxLayout.Y_AXIS));
		pan.setForeground(Color.BLACK);
		pan.setBackground(Color.BLACK);
		
		JScrollPane jsp = new JScrollPane(pan);
		mainpanel.add(jsp);
		
		if(sm != null) {
			JButton start = new JButton("Start Game");
			start.addActionListener(new ClickStart());
			start.setBackground(Color.black);
			start.setForeground(Color.white);
			mainpanel.add(start);
		}
		frame.setContentPane(mainpanel);
		frame.setSize(200, 180);
	}
	
	public void addPlayer(String s, int player_count) {

		JLabel newp = new JLabel(s);
		newp.setForeground(Aux_GUI.colors[player_count]);
		pan.add(newp);
		pan.revalidate();
		pan.repaint();
	}
	
	public void closeLobby() {
		frame.setVisible(false);
	}
	
	public void showLobby() {
		frame.setVisible(true);
	}
	
	private class ClickStart implements ActionListener{
			public void actionPerformed(ActionEvent arg0) {
				frame.setVisible(false);
				sm.startGame();
			}
	    }
}
